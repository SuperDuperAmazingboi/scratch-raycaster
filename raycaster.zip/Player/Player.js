/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Useless.", "./Player/costumes/Useless..svg", {
        x: 6.137488093357177,
        y: 5.723070733836636
      }),
      new Costume("hitbox", "./Player/costumes/hitbox.png", { x: 4, y: 4 })
    ];

    this.sounds = [new Sound("Meow", "./Player/sounds/Meow.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.KEY_PRESSED,
        { key: "space" },
        this.whenKeySpacePressed
      )
    ];
  }

  *tryMove(dx, dy) {
    this.x += dx;
    this.y += dy;
    if (this.touching(this.sprites["Level"].andClones())) {
      this.x += 0 - dx;
      this.y += 0 - dy;
    }
  }

  *move(steps) {
    this.costume = "hitbox";
    this.rotationStyle = Sprite.RotationStyle.DONT_ROTATE;
    this.warp(this.tryMove)(steps * Math.sin(this.degToRad(this.direction)), 0);
    this.warp(this.tryMove)(0, steps * Math.cos(this.degToRad(this.direction)));
    this.costume = "Useless.";
    this.rotationStyle = Sprite.RotationStyle.ALL_AROUND;
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.rotationStyle = Sprite.RotationStyle.ALL_AROUND;
    this.direction = 45;
    this.costume = "Useless.";
    this.effects.ghost = 100;
    while (true) {
      if (this.keyPressed("left arrow")) {
        this.direction -= 3.5;
      }
      if (this.keyPressed("right arrow")) {
        this.direction += 3.5;
      }
      if (this.keyPressed("up arrow")) {
        yield* this.move(3);
      }
      if (this.keyPressed("down arrow")) {
        yield* this.move(-3);
      }
      yield* this.broadcastAndWait("Raycast");
      yield;
    }
  }

  *whenKeySpacePressed() {
    this.effects.clear();
    yield* this.wait(0.2);
    while (!this.keyPressed("space")) {
      this.audioEffects.clear();
      yield;
    }
    this.effects.ghost = 100;
  }
}
