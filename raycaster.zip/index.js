import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Player from "./Player/Player.js";
import Level from "./Level/Level.js";
import CasterDeLaRaysrplayer2 from "./CasterDeLaRaysrplayer2/CasterDeLaRaysrplayer2.js";
import Level2 from "./Level2/Level2.js";
import Level3 from "./Level3/Level3.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Player: new Player({
    x: -8.109156401100106,
    y: 130.3194493662,
    direction: -18,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 2
  }),
  Level: new Level({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 5
  }),
  CasterDeLaRaysrplayer2: new CasterDeLaRaysrplayer2({
    x: 239,
    y: -112.37169871735198,
    direction: 12,
    costumeNumber: 1,
    size: 1.3888888888888888,
    visible: true,
    layerOrder: 1
  }),
  Level2: new Level2({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 3
  }),
  Level3: new Level3({
    x: 0,
    y: 0,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 4
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
