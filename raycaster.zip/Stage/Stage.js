/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 362.61261261261257,
        y: 205.20421469969972
      })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.fov = 60;
    this.vars.res = 4;
    this.vars.dir = -18;
    this.vars.res2 = 2;
    this.vars.time = 1204.154;

    this.watchers.fov = new Watcher({
      label: "FOV",
      style: "slider",
      visible: true,
      value: () => this.vars.fov,
      setValue: value => {
        this.vars.fov = value;
      },
      x: 245,
      y: 175
    });
    this.watchers.res2 = new Watcher({
      label: "RES",
      style: "slider",
      visible: true,
      value: () => this.vars.res2,
      setValue: value => {
        this.vars.res2 = value;
      },
      x: 245,
      y: 129
    });
  }
}
