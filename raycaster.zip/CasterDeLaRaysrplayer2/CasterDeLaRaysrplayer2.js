/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class CasterDeLaRaysrplayer2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("hitbox", "./CasterDeLaRaysrplayer2/costumes/hitbox.png", {
        x: 4,
        y: 4
      }),
      new Costume(
        "costume1",
        "./CasterDeLaRaysrplayer2/costumes/costume1.png",
        { x: 480, y: 360 }
      )
    ];

    this.sounds = [
      new Sound("Meow", "./CasterDeLaRaysrplayer2/sounds/Meow.wav")
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Raycast" },
        this.whenIReceiveRaycast
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];

    this.vars.x = 241;
    this.vars.distance = 35.59615139449998;
    this.vars.height = 112.37169871735198;
    this.vars.scanLines = 240;
  }

  *raycast() {
    this.stage.vars.dir = this.direction;
    this.vars.x = this.stage.vars.res2 / 2 - 240;
    if (this.stage.vars.res2 < 4) {
      this.vars.x = Math.round(this.vars.x);
    }
    this.direction -= this.stage.vars.fov / 2;
    this.vars.scanLines = 480 / this.stage.vars.res2;
    for (let i = 0; i < this.vars.scanLines; i++) {
      this.penColor.h += 10;
      this.warp(this.singleRay)();
      this.direction += this.stage.vars.fov / this.vars.scanLines;
      this.vars.x += this.stage.vars.res2;
    }
  }

  *whenIReceiveRaycast() {
    this.clearPen();
    this.penSize = this.stage.vars.res2;
    this.direction = this.sprites["Player"].direction;
    yield* this.raycast();
  }

  *whenGreenFlagClicked() {
    this.costume = "costume1";
    this.size = 1;
    this.stage.vars.fov = 60;
    this.stage.vars.res2 = 8;
    this.costume = "hitbox";
    this.rotationStyle = Sprite.RotationStyle.DONT_ROTATE;
    this.effects.ghost = 100;
  }

  *singleRay() {
    this.goto(this.sprites["Player"].x, this.sprites["Player"].y);
    this.warp(this.fastProximityRay)();
    while (!!this.touching(this.sprites["Level"].andClones())) {
      this.move(-0.5);
    }
    if (this.touching(this.sprites["Level2"].andClones())) {
      this.penColor.s = 100;
    } else {
      this.penColor.s = 0;
    }
    this.vars.distance = Math.hypot(
      this.sprites["Player"].x - this.x,
      this.sprites["Player"].y - this.y
    );
    this.vars.distance =
      this.vars.distance *
      Math.cos(this.degToRad(this.direction - this.stage.vars.dir));
    this.penColor.v = 100 - this.vars.distance / 1.2;
    this.vars.height = 4000 / this.vars.distance;
    this.goto(this.vars.x, this.vars.height);
    this.penDown = true;
    this.y = 0 - this.vars.height;
    this.penDown = false;
  }

  *fastProximityRay() {
    while (true) {
      if (!this.touching(this.sprites["Level3"].andClones())) {
        this.move(10);
        while (!this.touching(this.sprites["Level3"].andClones())) {
          this.move(10);
        }
        this.move(-6);
      }
      for (let i = 0; i < 10; i++) {
        this.move(1);
        if (this.touching(this.sprites["Level"].andClones())) {
          return;
        }
      }
    }
  }
}
